import UIKit

let day = "Friday"

if day == "Friday"{
    print("It is time for a great rest!")
} else{
    print("Still weekday!")
}
